let myText = document.querySelector("#myText");
let output = document.querySelector("#output");



// challenge 1: 
// as we type into the input box, 
// the text should appear inside the "ouput" p tag:







// function to spin an element 
function spin(element){
    element.style.transition = "all 1s linear"
    element.style.transform = "rotate(360deg)"
}



// -------- PART 2
let myButton = document.querySelector("#myButton");







let messageBoard = document.querySelector("#messageBoard");









// function to add text to the div with id "messageboard"
function addMessage(messagetext){
    let p = document.createElement("p");
    p.innerText = messagetext;
    messageBoard.prepend(p);
}

// function to rapidly increase the size of an element
function supersize(element){
    element.style.transition = "all .5s linear"
    element.style.transform = "scale(100)"
}

